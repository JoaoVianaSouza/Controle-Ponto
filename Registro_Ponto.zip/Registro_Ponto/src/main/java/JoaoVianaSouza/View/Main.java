package JoaoVianaSouza.View;

import JoaoVianaSouza.Controller.SistemaPontoController;

public class Main {
    public static void main(String[] args) {
        SistemaPontoController controller = new SistemaPontoController();
        try {
            new RelatorioView().exibirRelatorio(controller.getRegistros());
        } catch (Exception e) {
            System.out.println("Erro ao exibir relatório: " + e.getMessage());
        }
    }
}
