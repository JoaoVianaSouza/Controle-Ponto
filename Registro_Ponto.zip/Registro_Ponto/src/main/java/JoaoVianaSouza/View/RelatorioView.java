package JoaoVianaSouza.View;
import JoaoVianaSouza.Model.RegistroDePonto;
import JoaoVianaSouza.Model.Colaborador;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class RelatorioView {
    public void exibirRelatorio(List<RegistroDePonto> registros) throws IOException {
        String caminho = "sistemaPonto.txt";
        BufferedWriter writer = new BufferedWriter(new FileWriter(caminho));

        writer.write("Controle de ponto dos funcionarios\n");
        writer.write("===================================\n\n");

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd ' - Horário: ' HH:mm");

        for (RegistroDePonto registro : registros) {
            Colaborador colaborador = registro.getColaborador();

            System.out.println("---------------------------------------------------------");
            System.out.println("REGISTRO DE PONTO");
            System.out.println("Colaborador: " + colaborador.getNome());
            System.out.println("Ocupação: " + colaborador.getTipo());
            System.out.println("Entrada: " + registro.getEntrada().format(formatter));
            System.out.println("Saída: " + registro.getSaida().format(formatter));
            System.out.printf("Horas Trabalhadas: %.2fh%n", registro.getHorasTrabalhadas());
            System.out.printf("Saldo de Horas: %.2fh%n", registro.getSaldoDeHoras());
            System.out.println("---------------------------------------------------------");

            writer.write("---------------------------------------------------------\n");
            writer.write("Colaborador: " + colaborador.getNome() + "\n");
            writer.write("Ocupação: " + colaborador.getTipo() + "\n");
            writer.write("Entrada: " + registro.getEntrada().format(formatter) + "\n");
            writer.write("Saída: " + registro.getSaida().format(formatter) + "\n");
            writer.write(String.format("Horas Trabalhadas: %.2fh\n", registro.getHorasTrabalhadas()));
            writer.write(String.format("Saldo de Horas: %.2fh\n", registro.getSaldoDeHoras()));
            writer.write("---------------------------------------------------------\n");
        }

        writer.write("Feito por: João Pedro, Alysson, Pedro Henrique e Victor\n");
        writer.close();

        System.out.println("Arquivo de relatório criado com sucesso: " + caminho);
        System.out.println("Feito por: João Pedro, Alysson, Pedro Henrique e Victor");
    }
}

