package JoaoVianaSouza.Controller;

import JoaoVianaSouza.Model.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SistemaPontoController {
    private final List<Colaborador> colaboradores = new ArrayList<>();
    private final List<RegistroDePonto> registros = new ArrayList<>();

    public SistemaPontoController() {
        // Adicionar 7 funcionários no total (2 já tinham)
        colaboradores.add(new Efetivo("12345678900", "João Silva", 4500.0));
        colaboradores.add(new Estagiario("98765432100", "Maria Souza", 1200.0));
        colaboradores.add(new Efetivo("11122233344", "Lucas Carvalho", 3200.0));
        colaboradores.add(new Efetivo("22233344455", "Ana Beatriz", 3900.0));
        colaboradores.add(new Estagiario("33344455566", "Carlos Eduardo", 900.0));
        colaboradores.add(new Efetivo("44455566677", "Fernanda Lima", 5000.0));
        colaboradores.add(new Estagiario("55566677788", "Paulo Oliveira", 1100.0));

        // Mock de registros de ponto
        registros.add(new RegistroDePonto(colaboradores.get(0),
                LocalDateTime.of(2025, 5, 1, 8, 0),
                LocalDateTime.of(2025, 5, 1, 17, 0)));

        registros.add(new RegistroDePonto(colaboradores.get(1),
                LocalDateTime.of(2025, 5, 1, 9, 30),
                LocalDateTime.of(2025, 5, 1, 14, 30)));

        registros.add(new RegistroDePonto(colaboradores.get(2),
                LocalDateTime.of(2025, 5, 1, 8, 15),
                LocalDateTime.of(2025, 5, 1, 17, 15)));

        registros.add(new RegistroDePonto(colaboradores.get(3),
                LocalDateTime.of(2025, 5, 1, 7, 50),
                LocalDateTime.of(2025, 5, 1, 16, 45)));

        registros.add(new RegistroDePonto(colaboradores.get(4),
                LocalDateTime.of(2025, 5, 1, 10, 0),
                LocalDateTime.of(2025, 5, 1, 15, 0)));

        registros.add(new RegistroDePonto(colaboradores.get(5),
                LocalDateTime.of(2025, 5, 1, 9, 0),
                LocalDateTime.of(2025, 5, 1, 18, 0)));

        registros.add(new RegistroDePonto(colaboradores.get(6),
                LocalDateTime.of(2025, 5, 1, 9, 45),
                LocalDateTime.of(2025, 5, 1, 15, 15)));
    }

    public List<Colaborador> getColaboradores() {
        return colaboradores;
    }

    public List<RegistroDePonto> getRegistros() {
        return registros;
    }
}
