package JoaoVianaSouza.Model;

import java.time.Duration;
import java.time.LocalDateTime;

public class RegistroDePonto {
    private final Colaborador colaborador;
    private final LocalDateTime entrada;
    private final LocalDateTime saida;

    public RegistroDePonto(Colaborador colaborador, LocalDateTime entrada, LocalDateTime saida) {
        this.colaborador = colaborador;
        this.entrada = entrada;
        this.saida = saida;
    }

    public Colaborador getColaborador() {
        return colaborador;
    }

    public LocalDateTime getEntrada() {
        return entrada;
    }

    public LocalDateTime getSaida() {
        return saida;
    }

    public double getHorasTrabalhadas() {
        Duration duracao = Duration.between(entrada, saida);
        return duracao.toMinutes() / 60.0;
    }

    public double getSaldoDeHoras() {
        double horasEsperadas;
        if (colaborador instanceof Efetivo) {
            horasEsperadas = 8.0;
        } else {
            horasEsperadas = 6.0;
        }

        return getHorasTrabalhadas() - horasEsperadas;
    }


}
