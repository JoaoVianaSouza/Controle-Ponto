package JoaoVianaSouza.Model;

public abstract class Colaborador implements Registravel {
    private String cpf;
    private String nome;
    private int horasObrigatoriasDia;

    public Colaborador(String cpf, String nome, int horasObrigatoriasDia) {
        this.cpf = cpf;
        this.nome = nome;
        this.horasObrigatoriasDia = horasObrigatoriasDia;
    }

    public String getCpf() {
        return cpf;
    }

    public String getNome() {
        return nome;
    }

    public int getHorasObrigatoriasDia() {
        return horasObrigatoriasDia;
    }

    public abstract String getTipo();

    @Override
    public void registrarEntrada() {
        System.out.println(nome + " registrou entrada.");
    }

    @Override
    public void registrarSaida() {
        System.out.println(nome + " registrou saída.");
    }

    @Override
    public String toString() {
        return "CPF: " + cpf + ", Nome: " + nome + ", Tipo: " + getTipo();
    }
}
