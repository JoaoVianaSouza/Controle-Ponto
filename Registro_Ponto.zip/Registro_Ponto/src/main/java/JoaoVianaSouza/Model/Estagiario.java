package JoaoVianaSouza.Model;

public class Estagiario extends Colaborador {
    private double bolsaAuxilio;

    public Estagiario(String cpf, String nome, double bolsaAuxilio) {
        super(cpf, nome, 6);
        this.bolsaAuxilio = getBolsaAuxilio();
    }

    public double getBolsaAuxilio() { return bolsaAuxilio; }

    @Override
    public String getTipo() {
        return "Estagiário";
    }
}


