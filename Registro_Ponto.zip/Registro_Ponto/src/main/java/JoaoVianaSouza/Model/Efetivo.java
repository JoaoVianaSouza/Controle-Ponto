package JoaoVianaSouza.Model;

public class Efetivo extends Colaborador {
    private double salario;

    public Efetivo(String cpf, String nome, double salario) {
        super(cpf, nome, 8);
        this.salario = getSalario();
    }

    public double getSalario() { return salario; }

    @Override
    public String getTipo() {
        return "Efetivo";
    }
}

