package JoaoVianaSouza.Model;

public interface Registravel {
    void registrarEntrada();
    void registrarSaida();
}
